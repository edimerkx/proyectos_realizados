function [z_out, z_N2, z_B2, z_dis, y_N1, y_B1] = FM_DEMOD_Adrian657668(x, B1, N1, B2, N2, fs);
% entradas
% x = senal de entrada
% B1 = ancho 3dB filtro pasa bajos de la estacion de radio.
% N1 = valor de diezmado luego del primer filtrado pasa bajos.
% B2 = ancho 3dB filtro pasa bajos de la senal pasada por el discriminador.
% N2 = valor de diezmado luego del segundo filtrado pasa bajos.
% fs = frecuencia de muestreo de x.
% salidas:
% y_B1 = senal luego del primer filtro pasa bajos.
% y_N1 = senal y_B1 diezmada en N1.
% z_dis = senal que sale del discriminador.
% z_B2 = z_dis filtrada pasa bajos en un ancho B2.
% z_N2 = se~nal z_B2 diesmada en N2.
% z_out = z_N2.


n = length(x);                                  %nro de muestras 
%==================================================================================
% LPF 1
    wn1 = B1/(fs/2) ;                           % Frecuencia de corte normalizada 0<wn<1
    [a1,b1] = butter(5,wn1);                    % Filtro Butterworth de orden 5 
    y_B1 = filter(a1,b1,x);                     % Se�al Yb1, obtenida con el LPF 1 
%=================================================================================
% Diezmado 1
    y_N1 = decimate(y_B1,N1,'fir');             % y_N1[m] Secuencia diezmada de a N1 muestras
    fs_yn1 = fs/N1;                             % Frecuencia de muestreo 
    L_yn1 = n/N1;                               % Numero de muestras de x despues de diezmar 
%==================================================================================
% Discriminador de frecuencia
    fase = angle(y_N1);                         % fase
    z_dis = (diff(unwrap(fase)))/(2*pi/fs_yn1); % mensaje
%==================================================================================
% LPF 2
    wn2 = B2/(fs_yn1/2) ;                       % Frecuencia corte normalizada  0<wn<1
    [a2,b2]=butter(5,wn2);                      % Filtro Butterworth de orden 5 
    z_B2=filter(a2,b2,z_dis);                   % Se�al Yb2, obtenida con el LPF 2
%=================================================================================
% Diezmado 2
    z_N2 = decimate(z_B2,N2,'fir');             % y_N2[m] Secuencia diezmada
    fs_yn2 = fs_yn1/N2;                         % Nueva frecuencia de muestreo luego de diezmar
    L_yn2 = L_yn1/N2;                           % Nuevas muestras de yB1
%================================================================================
% Mensaje normalizado
    z_out = z_N2/max(abs(z_N2));
%larg=length(z_out)
    sound(z_out,fs_yn2);
 

