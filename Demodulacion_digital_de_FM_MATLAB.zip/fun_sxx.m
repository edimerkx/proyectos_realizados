function [] = fun_sxx(x,fs,n,titulo)
    
     if(n>2e6)
      M = 200;                                   % Cantidad de segmentos
      N = round(n/M);                            % redondeo del vector a M intervalos
     else

      M = 160;                                   % cantidad necesaria para la resolucion
      N = round(n/M);
     end
 %estructura seguida del apunte
    for k = 0:(M-1)                         %Creo los segmentos   n1=M2=1K fs1=fs2=102K,    n2=M1=2e6 y fs2=204e3
     xk = x(k*N + 1:(k+1)*N);               %Creacion segmento k-esimo
     A(:,k+1) = (abs(fft(xk)).^2)./(fs*N);  %Matriz con las M DEPs individuales por columna
    end

    for i=1:N
     Sxx(i)= sum (A(i,:) ) / M ;            %Estimacion de DEP por el promedio de las DEPs individuales
    end
    
    
df=fs/N;                                    %resolucion
Sxx = 10*log10( fftshift(Sxx));             %Desplazo la componente de frecuencia cero y convierto a dB
f =(-N/2 : N/2 -1)*df;                      %Centro el vector de frecuencias


%grafica 

    figure;
    plot(f,Sxx)
    xlim([f(1) f(end)]);  % Establece los l�mites del eje x del gr�fico para abarcar desde la primera frecuencia hasta la �ltima en el vector de f
    switch titulo         % estructura para los diferentes titulos 
        case 'DEP x'
            title('DEP x');
        case 'DEP YN1'
            title('DEP YN1');
        case 'DEP YB1'
            title('DEP YB1');    
        case 'DEP zDIS'
            title('DEP zDIS');
        case 'DEP zB2'
            title('DEP zB2');
        case 'DEP zN2'
            title('DEP zN2');
        case 'DEP zout'
            title('DEP zout');
        otherwise
            error('T�tulo no reconocido');
    end
    
    xlabel('f[Hz]');
    ylabel('S_{xx}^{(m)}(f)');
    grid on;

end
