clear all;
close all;
clc;
%===============================================================================================
fs = 2.04e6;
fc = 94.9e6;
spf = 256 * 64;
hSDR = comm.SDRRTLReceiver('RadioAddress','0', 'CenterFrequency', fc, 'SampleRate', fs, 'OutputDataType', 'Double', 'SamplesPerFrame', spf, 'FrequencyCorrection', 0);
dur = 10;
frames = floor(dur * fs / spf);
hLogger = dsp.SignalSink;
for counter = 1:frames
    data = step(hSDR);
    step(hLogger, data);
end
x = hLogger.Buffer;
%========================================================================================
n = length(x) % Nro de muestras en x

B1 = 100e3;         % Ancho de banda de Carson 
N1 = 10;            % primer diezmado
fs1=fs/N1;          % resolucion 1 
M1= n/N1;           % obtengo M muestras
B2 = 15e3;          % Ancho de banda de se�al m(t)
N2 = 2;             % Factor de diezmado 2, considerando que la fs es de 48 kHZ
NT=N1*N2;           % diezmado total
M2= n/NT;           % segundo diezmado
fs2=fs/NT;          % resolucion 2

% grafico de la se�al pura
figure;
plot(abs(fftshift(fft(x)))); % Visualizar la magnitud de la FFT
title('Espectro de la se�al capturada');
xlabel('Frecuencia (bins)');
ylabel('Magnitud');
[z_out, z_N2, z_B2, z_dis, y_N1, y_B1] = FM_DEMOD_Adrian657668(x, B1, N1, B2, N2, fs);
fun_sxx(x,fs,n,'DEP x'); 
fun_sxx(y_B1,fs,n,'DEP YB1');
fun_sxx(y_N1,fs1,M1,'DEP YN1');
fun_sxx(z_dis,fs1,M1,'DEP zDIS');
fun_sxx(z_B2,fs1,M1,'DEP zB2'); 
fun_sxx(z_N2,fs2,M2,'DEP zN2');       
fun_sxx(z_out,fs2,M2,'DEP zout');



